# MarkMirror — ResultRadar Rush (Enhanced Edition)

MarkMirror is a result lookup and cohort analytics dashboard. This upgraded edition adds a persistent SQLite data layer, explainable academic intervention insights, API validation, operational safeguards, structured request logs and automated tests while retaining the existing dashboard design and core result workflows.

## Requirements
- Node.js **22.5 or newer** (uses the built-in `node:sqlite` module; no separate database server is required).
- npm.

## Quick start (Windows PowerShell / macOS / Linux)
```bash
npm install
npm test
npm start
```
Open **http://localhost:3000**. On Windows PowerShell, if script execution blocks `npm`, run `npm.cmd install`, `npm.cmd test` and `npm.cmd start`.

The SQLite database is created automatically at `data/markmirror.sqlite` on first launch. The supplied JSON dataset is imported once when the database is empty; subsequent launches read the persistent SQLite records. To reset the sample data, stop the server, delete the SQLite database files, and restart. Set `DB_PATH` to use a different database location.

## Main features
- Hall-ticket result lookup with credit-weighted SGPA / CGPA and branch rank.
- Cohort analytics, subject pass rates, grade distribution and difficulty index.
- Department leaderboard, batch comparison, printable marksheet and re-evaluation fee estimator.
- **Smart Academic Insights:** transparent rules identify subject-level failure patterns, students needing early support and high-performing cohorts. Each insight displays evidence and a suggested action; it is decision support, not an opaque prediction.
- **SQLite persistence:** student result records and operational audit events are stored in a local relational database.
- **API reliability:** server-side request validation, JSON body size limit, rate limiting, security headers, request IDs and consistent error responses.

## API reference
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/branches` | Available branches |
| GET | `/api/student/:hallTicket` | Student result |
| GET | `/api/analytics?branch=ALL` | Cohort analytics |
| GET | `/api/leaderboard?branch=CSE` | Top 10 in a branch |
| GET | `/api/batches/compare` | Historical batch comparison |
| GET | `/api/insights?branch=ALL` | Explainable academic recommendations |
| POST | `/api/reeval/estimate` | Validated fee estimate |

Example request body for the fee estimator:
```json
{"hallTicket":"22CSE104","subjects":["CS203"],"type":"revaluation"}
```

## Tests and quality checks
- `npm test` runs grade boundary, weighted GPA, classification, service, insights and HTTP API tests using Node's built-in test runner.
- `npm run check` performs JavaScript syntax checks.
- `npm run seed` regenerates the sample JSON data; the next server start syncs it into SQLite.

## Project structure
```text
server.js                  Express routes, validation, safeguards and logging
services/grades.js         Grade scale and weighted GPA calculations
services/resultService.js Result, analytics, leaderboard and insight domain logic
services/database.js      SQLite schema, seed sync, persistence and audit events
tests/                     Automated unit and API tests
scripts/                   Sample data generator
data/                      Seed JSON and runtime SQLite database
public/                     Frontend dashboard, charts and styles
```

## Dataset and assumptions
The included student dataset and historical batch statistics are sample/demo data, not official university records. Re-evaluation fees are placeholders (₹500 recounting / ₹1,000 revaluation per paper); update `REEVAL_FEES` to match an institution's actual policy. The university name in the marksheet is a placeholder. Protect the demo audit endpoint and add institutional authentication/authorization before production deployment.
