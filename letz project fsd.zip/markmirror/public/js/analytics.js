import { api, esc, drawChart } from './api.js';

const GRADE_COLORS = ['#1f9d63', '#4cb782', '#7bcf9f', '#f2c94c', '#f2a900', '#f08a4b', '#c9d1e3', '#d64545'];

export async function initAnalytics(branches) {
  const select = document.getElementById('analyticsBranch');
  select.innerHTML = '<option value="ALL">All branches</option>' +
    branches.map((b) => `<option value="${b.code}">${esc(b.name)}</option>`).join('');
  select.addEventListener('change', () => loadAnalytics(select.value));
  await loadAnalytics('ALL');
}

async function loadAnalytics(branch) {
  const data = await api.analytics(branch);
  renderStats(data.summary);
  renderPassChart(data.subjectStats);
  renderGradeChart(data.gradeDistribution);
  renderCgpaChart(data.cgpaBins);
  renderDifficulty(data.subjectStats);
  renderBranches(data.branchStats);
}

function renderStats(s) {
  document.getElementById('statGrid').innerHTML = `
    <div class="stat"><span>Students</span><strong>${s.students}</strong></div>
    <div class="stat"><span>Cleared all subjects</span><strong>${s.passPercentage}%</strong></div>
    <div class="stat"><span>Average CGPA</span><strong>${s.avgCgpa}</strong><small>avg SGPA ${s.avgSgpa}</small></div>
    <div class="stat"><span>Toughest paper</span><strong>${esc(s.hardestSubject)}</strong><small>only ${s.hardestPassRate}% passed</small></div>`;
}

function renderPassChart(stats) {
  drawChart('passChart', {
    type: 'bar',
    data: {
      labels: stats.map((s) => s.name),
      datasets: [
        { label: 'Pass %', data: stats.map((s) => s.passRate), backgroundColor: '#1f9d63' },
        { label: 'Fail %', data: stats.map((s) => s.failRate), backgroundColor: '#d64545' }
      ]
    },
    options: {
      maintainAspectRatio: false,
      scales: { x: { stacked: true }, y: { stacked: true, max: 100 } }
    }
  });
}

function renderGradeChart(dist) {
  drawChart('gradeChart', {
    type: 'doughnut',
    data: {
      labels: Object.keys(dist),
      datasets: [{ data: Object.values(dist), backgroundColor: GRADE_COLORS }]
    },
    options: { maintainAspectRatio: false, plugins: { legend: { position: 'right' } } }
  });
}

function renderCgpaChart(bins) {
  // show low -> high so it reads like a normal histogram
  const ordered = [...bins].reverse();
  drawChart('cgpaChart', {
    type: 'bar',
    data: {
      labels: ordered.map((b) => b.label),
      datasets: [{ label: 'Students', data: ordered.map((b) => b.count), backgroundColor: '#14213d', barPercentage: 1, categoryPercentage: 0.95 }]
    },
    options: {
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true, ticks: { precision: 0 } }, x: { title: { display: true, text: 'CGPA range' } } }
    }
  });
}

function renderDifficulty(stats) {
  const sorted = [...stats].sort((a, b) => b.difficultyIndex - a.difficultyIndex);
  document.getElementById('difficultyTable').innerHTML = `
    <tr><th>Subject</th><th>Index</th><th>Level</th></tr>
    ${sorted.map((s) => `<tr><td>${esc(s.name)}</td><td>${s.difficultyIndex}</td><td><span class="tag ${s.difficulty}">${s.difficulty}</span></td></tr>`).join('')}`;
}

function renderBranches(rows) {
  document.getElementById('branchTable').innerHTML = `
    <tr><th>Branch</th><th>Students</th><th>Pass %</th><th>Avg SGPA</th></tr>
    ${rows.map((b) => `<tr><td>${esc(b.code)}</td><td>${b.students}</td><td>${b.passPercentage}%</td><td>${b.avgSgpa}</td></tr>`).join('')}`;
}
