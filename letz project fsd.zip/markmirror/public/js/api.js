// tiny wrapper around fetch so the other files stay readable
async function request(url, options) {
  const res = await fetch(url, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}

export const api = {
  get: (url) => request(url),
  branches: () => request('/api/branches'),
  student: (ht) => request(`/api/student/${encodeURIComponent(ht)}`),
  analytics: (branch) => request(`/api/analytics?branch=${branch || 'ALL'}`),
  leaderboard: (branch) => request(`/api/leaderboard?branch=${branch}`),
  compare: () => request('/api/batches/compare'),
  reeval: (hallTicket, subjects, type) =>
    request('/api/reeval/estimate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ hallTicket, subjects, type })
    })
};

export const GRADE_POINTS = { 'O': 10, 'A+': 9, 'A': 8, 'B+': 7, 'B': 6, 'C': 5, 'P': 4, 'F': 0 };

// names are plain text but let's not trust anything going into innerHTML
export function esc(text) {
  return String(text).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// keep one chart per canvas, destroy the old one before drawing again
const charts = {};
export function drawChart(canvasId, config) {
  if (typeof Chart === 'undefined') {
    const box = document.getElementById(canvasId).parentElement;
    box.innerHTML = '<p class="muted">Chart.js could not load (check your internet connection).</p>';
    return;
  }
  if (charts[canvasId]) charts[canvasId].destroy();
  charts[canvasId] = new Chart(document.getElementById(canvasId), config);
}
