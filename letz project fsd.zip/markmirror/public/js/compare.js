import { api, esc, drawChart } from './api.js';

const COLORS = ['#c9d1e3', '#f2a900', '#14213d'];

export async function initCompare() {
  const data = await api.compare();
  const labels = data.batches.map((b) => `Batch ${b.batch}`);

  drawChart('compareChart', {
    type: 'bar',
    data: {
      labels,
      datasets: [
        { label: 'Avg CGPA (x10)', data: data.batches.map((b) => +(b.avgCgpa * 10).toFixed(1)), backgroundColor: '#14213d' },
        { label: 'Pass %', data: data.batches.map((b) => b.passPercentage), backgroundColor: '#f2a900' },
        { label: 'Distinction %', data: data.batches.map((b) => b.distinctionPercentage), backgroundColor: '#1f9d63' }
      ]
    },
    options: { maintainAspectRatio: false, scales: { y: { beginAtZero: true, max: 100 } } }
  });

  drawChart('compareFailChart', {
    type: 'bar',
    data: {
      labels: data.subjects.map((s) => s.name),
      datasets: data.batches.map((b, i) => ({
        label: `Batch ${b.batch}`,
        data: data.subjects.map((s) => b.subjectFailRates[s.code]),
        backgroundColor: COLORS[i % COLORS.length]
      }))
    },
    options: { maintainAspectRatio: false, scales: { y: { beginAtZero: true } } }
  });

  document.getElementById('compareTable').innerHTML = `
    <tr><th>Batch</th><th>Students</th><th>Avg CGPA</th><th>Pass %</th><th>Distinction %</th></tr>
    ${data.batches.map((b) => `
      <tr><td>${b.batch}</td><td>${b.students}</td><td>${b.avgCgpa}</td><td>${b.passPercentage}%</td><td>${b.distinctionPercentage}%</td></tr>`).join('')}`;
}
