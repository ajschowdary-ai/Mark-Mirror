import { api, esc } from './api.js';

export async function initInsights(branches) {
  const select = document.getElementById('insightsBranch');
  const list = document.getElementById('insightsList');
  select.innerHTML = '<option value="ALL">All branches</option>' + branches.map((b) => `<option value="${esc(b.code)}">${esc(b.code)}</option>`).join('');
  async function load() {
    list.innerHTML = '<p class="muted">Analysing cohort data…</p>';
    try {
      const data = await api.get(`/api/insights?branch=${encodeURIComponent(select.value)}`);
      if (!data.insights.length) { list.innerHTML = '<div class="card"><h3>No intervention alerts</h3><p class="muted">No current rule thresholds were triggered for this selection.</p></div>'; return; }
      list.innerHTML = data.insights.map((item) => `<article class="insight-card priority-${esc(item.priority)}"><div class="insight-top"><span class="priority-label">${esc(item.priority)} priority</span><span class="muted">${esc(item.category)}</span></div><h3>${esc(item.title)}</h3><p><strong>Evidence:</strong> ${esc(item.evidence)}</p><p><strong>Suggested action:</strong> ${esc(item.recommendation)}</p></article>`).join('') + `<p class="muted insight-foot">Generated ${esc(new Date(data.generatedAt).toLocaleString())}. ${esc(data.methodology)}</p>`;
    } catch (error) { list.innerHTML = `<p class="error">${esc(error.message || 'Could not load insights.')}</p>`; }
  }
  select.addEventListener('change', load);
  await load();
}
