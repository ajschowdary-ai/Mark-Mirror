import { api, esc } from './api.js';

const medals = ['🥇', '🥈', '🥉'];

export async function initLeaders(branches, onPick) {
  const select = document.getElementById('leaderBranch');
  select.innerHTML = branches.map((b) => `<option value="${b.code}">${esc(b.name)}</option>`).join('');
  select.addEventListener('change', () => load(select.value));

  // click on a hall ticket -> open that marksheet
  document.getElementById('leaderTable').addEventListener('click', (e) => {
    const link = e.target.closest('a[data-ht]');
    if (link) onPick(link.dataset.ht);
  });

  await load(select.value);
}

async function load(branch) {
  const rows = await api.leaderboard(branch);
  document.getElementById('leaderTable').innerHTML = `
    <tr><th>Rank</th><th>Student</th><th>Hall Ticket</th><th>SGPA</th><th>CGPA</th><th>Credits</th></tr>
    ${rows.map((r) => `
      <tr class="${r.rank === 1 ? 'top1' : ''}">
        <td class="rank">${medals[r.rank - 1] || r.rank}</td>
        <td>${esc(r.name)}</td>
        <td><a data-ht="${esc(r.hallTicket)}">${esc(r.hallTicket)}</a></td>
        <td><strong>${r.sgpa.toFixed(2)}</strong></td>
        <td>${r.cgpa.toFixed(2)}</td>
        <td>${r.creditsEarned}</td>
      </tr>`).join('')}`;
}
