import { api, esc, drawChart, GRADE_POINTS } from './api.js';

const form = document.getElementById('lookupForm');
const input = document.getElementById('hallTicket');
const errorBox = document.getElementById('lookupError');
const resultArea = document.getElementById('resultArea');

let current = null; // result currently on screen

export function initLookup() {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    loadResult(input.value);
  });

  document.querySelectorAll('.chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      input.value = chip.dataset.ht;
      loadResult(chip.dataset.ht);
    });
  });

  document.getElementById('printBtn').addEventListener('click', () => window.print());
  document.getElementById('reevalBtn').addEventListener('click', estimateFee);
}

// the leaderboard uses this to jump to someone's marksheet
export function showStudent(hallTicket) {
  input.value = hallTicket;
  loadResult(hallTicket);
}

async function loadResult(hallTicket) {
  const ht = hallTicket.trim().toUpperCase();
  if (!ht) return;
  errorBox.hidden = true;

  try {
    current = await api.student(ht);
    renderMarksheet(current);
    renderTrend(current);
    renderReevalOptions(current);
    resultArea.hidden = false;
  } catch (err) {
    resultArea.hidden = true;
    errorBox.textContent = err.message;
    errorBox.hidden = false;
  }
}

function renderMarksheet(r) {
  document.getElementById('msTitle').textContent = `Semester ${r.semester} Grade Sheet`;
  document.getElementById('msName').textContent = r.name;
  document.getElementById('msHT').textContent = r.hallTicket;
  document.getElementById('msBranch').textContent = r.branchName;
  document.getElementById('msBatch').textContent = `${r.batch} - ${r.batch + 4}`;

  document.getElementById('msRows').innerHTML = r.subjects.map((s) => `
    <tr class="${s.passed ? '' : 'failed'}">
      <td>${esc(s.code)}</td>
      <td class="left">${esc(s.name)}</td>
      <td>${s.credits}</td>
      <td>${s.internal}</td>
      <td>${s.external}</td>
      <td>${s.total}</td>
      <td class="${s.grade === 'F' ? 'g-F' : ''}"><strong>${s.grade}</strong></td>
      <td>${GRADE_POINTS[s.grade]}</td>
    </tr>`).join('');

  document.getElementById('msSgpa').textContent = r.sgpa.toFixed(2);
  document.getElementById('msCgpa').textContent = r.cgpa.toFixed(2);
  document.getElementById('msCredits').textContent = `${r.creditsEarned} / ${r.totalCredits}`;
  document.getElementById('msPct').textContent = `${r.percentage}%`;
  document.getElementById('msRank').textContent = `${r.branchRank} / ${r.branchStrength}`;

  const badge = document.getElementById('msStatus');
  badge.textContent = r.status === 'PASS' ? 'PASS' : `FAIL (${r.backlogs} backlog${r.backlogs > 1 ? 's' : ''})`;
  badge.className = `badge ${r.status === 'PASS' ? 'pass' : 'fail'}`;
  document.getElementById('msClass').textContent = r.classification;
}

function renderTrend(r) {
  drawChart('trendChart', {
    type: 'line',
    data: {
      labels: r.trend.map((t) => `Sem ${t.semester}`),
      datasets: [{
        label: 'SGPA',
        data: r.trend.map((t) => t.sgpa),
        borderColor: '#14213d',
        backgroundColor: 'rgba(242,169,0,.25)',
        fill: true,
        tension: 0.3,
        pointRadius: 5
      }]
    },
    options: {
      maintainAspectRatio: false,
      scales: { y: { min: 4, max: 10 } },
      plugins: { legend: { display: false } }
    }
  });
}

function renderReevalOptions(r) {
  document.getElementById('reevalSubjects').innerHTML = r.subjects.map((s) => `
    <label><input type="checkbox" value="${esc(s.code)}"> ${esc(s.name)} <span class="muted">(${s.grade})</span></label>
  `).join('');
  document.getElementById('reevalOut').innerHTML = '';
}

async function estimateFee() {
  const out = document.getElementById('reevalOut');
  const picked = [...document.querySelectorAll('#reevalSubjects input:checked')].map((c) => c.value);
  const type = document.querySelector('input[name="reevalType"]:checked').value;

  try {
    const fee = await api.reeval(current.hallTicket, picked, type);
    out.innerHTML = `
      ${fee.lines.map((l) => `<div>${esc(l.name)} &mdash; Rs. ${l.fee}</div>`).join('')}
      <div class="total">Total: Rs. ${fee.total}</div>`;
  } catch (err) {
    out.innerHTML = `<span class="error">${esc(err.message)}</span>`;
  }
}
