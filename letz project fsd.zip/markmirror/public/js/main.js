import { api } from './api.js';
import { initLookup, showStudent } from './lookup.js';
import { initAnalytics } from './analytics.js';
import { initLeaders } from './leaders.js';
import { initCompare } from './compare.js';
import { initInsights } from './insights.js';

const tabs = document.querySelectorAll('.tab');
const panels = document.querySelectorAll('.panel');

function switchTab(name) {
  tabs.forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
  panels.forEach((p) => p.classList.toggle('active', p.id === `tab-${name}`));
}

tabs.forEach((t) => t.addEventListener('click', () => switchTab(t.dataset.tab)));

async function start() {
  initLookup();

  try {
    const branches = await api.branches();
    // load the heavy tabs up front so switching is instant
    await Promise.all([
      initAnalytics(branches),
      initLeaders(branches, (ht) => { switchTab('lookup'); showStudent(ht); }),
      initCompare(),
      initInsights(branches)
    ]);
  } catch (err) {
    console.error('could not load dashboard data', err);
  }
}

start();
