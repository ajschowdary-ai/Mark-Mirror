// Makes data/students.json - 120 fake students, one semester of marks each.
// Seeded random so you get the same data every time you run it.
const fs = require('fs');
const path = require('path');

const subjects = require('../data/subjects.json');

let seed = Number(process.env.SEED) || 2;
function rand() {
  // mulberry32
  seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
const randInt = (a, b) => Math.floor(rand() * (b - a + 1)) + a;
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
function gauss(mean, sd) {
  const u = 1 - rand(), v = rand();
  return mean + sd * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

const firstNames = ['Aarav', 'Ananya', 'Karthik', 'Sneha', 'Rohit', 'Pooja', 'Vikram', 'Divya', 'Arjun', 'Meghana',
  'Sai', 'Harini', 'Nikhil', 'Lavanya', 'Teja', 'Keerthi', 'Manoj', 'Bhavana', 'Rahul', 'Swathi',
  'Varun', 'Priya', 'Abhinav', 'Nandini', 'Charan', 'Sowmya', 'Kiran', 'Tanvi', 'Yashwanth', 'Isha'];
const lastNames = ['Reddy', 'Sharma', 'Naidu', 'Rao', 'Kumar', 'Varma', 'Goud', 'Patel', 'Singh', 'Chowdary',
  'Iyer', 'Menon', 'Das', 'Yadav', 'Prasad', 'Gupta'];

// how many students per branch (hall tickets start at 101)
const branches = [
  { code: 'CSE', name: 'Computer Science & Engineering', count: 40 },
  { code: 'AIDS', name: 'CSE (AI & Data Science)', count: 30 },
  { code: 'IT', name: 'Information Technology', count: 25 },
  { code: 'ECE', name: 'Electronics & Communication', count: 25 }
];

// chance of failing each subject. OS is the nasty one on purpose (demo story)
const failChance = { MA201: 0.07, CS202: 0.04, CS203: 0.32, CS204: 0.08, CS205: 0.03, CS206: 0.01 };
const offsets = { MA201: -3, CS202: 1, CS203: -4, CS204: -1, CS205: 3, CS206: 6 };

function makeMarks(code, ability) {
  if (rand() < failChance[code]) {
    return { internal: randInt(18, 36), external: randInt(8, 23) };
  }
  const total = clamp(Math.round(gauss(ability + offsets[code], 8)), 42, 99);
  let internal = clamp(Math.round(total * 0.4 + gauss(0, 2)), 16, 40);
  let external = total - internal;
  if (external > 60) { external = 60; internal = total - 60; }
  if (external < 24) { external = 24; internal = Math.max(0, total - 24); }
  return { internal, external };
}

function makePrevious(ability) {
  const credits = [22, 22, 21];
  return credits.map((c, i) => ({
    semester: i + 1,
    sgpa: Math.round(clamp(gauss(ability / 10 + 0.1 * i, 0.45), 5.2, 9.8) * 100) / 100,
    credits: c
  }));
}

const students = [];
const usedNames = new Set();

for (const b of branches) {
  for (let i = 0; i < b.count; i++) {
    const hallTicket = `22${b.code}${101 + i}`;
    let name;
    do {
      name = `${firstNames[randInt(0, firstNames.length - 1)]} ${lastNames[randInt(0, lastNames.length - 1)]}`;
    } while (usedNames.has(name));
    usedNames.add(name);

    const ability = clamp(gauss(76, 10), 52, 95);
    students.push({
      hallTicket,
      name,
      branch: b.code,
      batch: 2022,
      semester: 4,
      subjects: subjects.map((s) => ({ code: s.code, ...makeMarks(s.code, ability) })),
      previousSemesters: makePrevious(ability)
    });
  }
}

// The demo student from the problem brief: 22CSE104 should land on SGPA 8.85
const demo = students.find((s) => s.hallTicket === '22CSE104');
demo.name = 'Ananya Reddy';
const demoMarks = { MA201: [34, 50], CS202: [37, 55], CS203: [30, 44], CS204: [33, 49], CS205: [29, 43], CS206: [35, 48] };
demo.subjects = subjects.map((s) => ({ code: s.code, internal: demoMarks[s.code][0], external: demoMarks[s.code][1] }));
demo.previousSemesters = [
  { semester: 1, sgpa: 8.1, credits: 22 },
  { semester: 2, sgpa: 8.42, credits: 22 },
  { semester: 3, sgpa: 8.67, credits: 21 }
];

fs.writeFileSync(path.join(__dirname, '../data/students.json'), JSON.stringify(students, null, 2));
console.log(`done, wrote ${students.length} students`);
