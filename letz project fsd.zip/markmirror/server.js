const express = require('express');
const path = require('node:path');
const crypto = require('node:crypto');
const svc = require('./services/resultService');
const { logEvent } = require('./services/database');

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const WINDOW_MS = 60_000;
const MAX_REQUESTS = 120;
const requests = new Map();

app.disable('x-powered-by');
app.use((req, res, next) => {
  res.set({ 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer', 'Permissions-Policy': 'camera=(), microphone=(), geolocation=()' });
  const key = req.ip || 'unknown';
  const now = Date.now();
  const bucket = requests.get(key) || { count: 0, start: now };
  if (now - bucket.start > WINDOW_MS) { bucket.count = 0; bucket.start = now; }
  bucket.count += 1; requests.set(key, bucket);
  res.set('X-RateLimit-Limit', String(MAX_REQUESTS));
  if (bucket.count > MAX_REQUESTS) return res.status(429).json({ error: 'Too many requests. Please try again shortly.' });
  next();
});
app.use(express.json({ limit: '20kb', strict: true }));
app.use((req, res, next) => {
  const requestId = crypto.randomUUID();
  req.requestId = requestId;
  res.set('X-Request-Id', requestId);
  const started = Date.now();
  res.on('finish', () => console.log(JSON.stringify({ level: 'info', requestId, method: req.method, path: req.path, status: res.statusCode, durationMs: Date.now() - started })));
  next();
});
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'MarkMirror API', timestamp: new Date().toISOString() }));
app.get('/api/branches', (req, res) => res.json(svc.listBranches()));
app.get('/api/student/:hallTicket', (req, res) => {
  const ticket = String(req.params.hallTicket || '').trim().toUpperCase();
  if (!/^[A-Z0-9-]{5,20}$/.test(ticket)) return res.status(400).json({ error: 'Enter a valid hall ticket (5–20 letters, numbers or hyphens).' });
  const result = svc.getStudent(ticket);
  if (!result) return res.status(404).json({ error: 'No result found for that hall ticket.' });
  logEvent('student_lookup', { hallTicket: ticket });
  res.json(result);
});
app.get('/api/analytics', (req, res) => {
  const branch = String(req.query.branch || 'ALL').toUpperCase();
  if (branch !== 'ALL' && !svc.listBranches().some((b) => b.code === branch)) return res.status(400).json({ error: 'Unknown branch.' });
  res.json(svc.getAnalytics(branch));
});
app.get('/api/leaderboard', (req, res) => {
  const branch = String(req.query.branch || 'CSE').toUpperCase();
  const board = svc.getLeaderboard(branch);
  if (!board) return res.status(400).json({ error: 'Unknown branch.' });
  res.json(board);
});
app.get('/api/batches/compare', (req, res) => res.json(svc.compareBatches()));
app.get('/api/insights', (req, res) => {
  const branch = String(req.query.branch || 'ALL').toUpperCase();
  if (branch !== 'ALL' && !svc.listBranches().some((b) => b.code === branch)) return res.status(400).json({ error: 'Unknown branch.' });
  res.json(svc.getInsights(branch));
});
app.post('/api/reeval/estimate', (req, res) => {
  const { hallTicket, subjects, type } = req.body || {};
  if (typeof hallTicket !== 'string' || !/^[A-Z0-9-]{5,20}$/i.test(hallTicket.trim())) return res.status(400).json({ error: 'A valid hallTicket is required.' });
  if (!Array.isArray(subjects) || subjects.length < 1 || subjects.length > 12 || subjects.some((code) => typeof code !== 'string' || !/^[A-Z0-9]{3,12}$/i.test(code))) return res.status(400).json({ error: 'Choose between 1 and 12 valid subject codes.' });
  if (!['recounting', 'revaluation'].includes(type)) return res.status(400).json({ error: 'type must be recounting or revaluation.' });
  const out = svc.estimateReeval(hallTicket, subjects, type);
  if (out.error) return res.status(out.status).json({ error: out.error });
  logEvent('reevaluation_estimate', { hallTicket: out.hallTicket, type, subjectCount: out.lines.length, total: out.total });
  res.json(out);
});
app.use('/api', (req, res) => res.status(404).json({ error: 'API route not found.' }));
app.use((err, req, res, next) => {
  console.error(JSON.stringify({ level: 'error', requestId: req.requestId, message: err.message }));
  if (res.headersSent) return next(err);
  const status = err.type === 'entity.parse.failed' ? 400 : 500;
  res.status(status).json({ error: status === 400 ? 'Invalid JSON request body.' : 'An unexpected server error occurred.', requestId: req.requestId });
});

if (require.main === module) app.listen(PORT, () => console.log(`MarkMirror is running -> http://localhost:${PORT}`));
module.exports = app;
