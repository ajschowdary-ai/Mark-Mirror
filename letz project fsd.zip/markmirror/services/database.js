// SQLite persistence using Node 22's built-in node:sqlite module.
// The JSON files remain the reproducible seed source; runtime reads come from SQLite.
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const dataDir = path.join(__dirname, '..', 'data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new DatabaseSync(process.env.DB_PATH || path.join(dataDir, 'markmirror.sqlite'));
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS students (
    hall_ticket TEXT PRIMARY KEY, name TEXT NOT NULL, branch TEXT NOT NULL,
    batch INTEGER NOT NULL, semester INTEGER NOT NULL, record_json TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE INDEX IF NOT EXISTS idx_students_branch ON students(branch);
  CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT, event TEXT NOT NULL,
    detail_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

function seedStudents(records) {
  const insert = db.prepare(`INSERT INTO students
    (hall_ticket, name, branch, batch, semester, record_json)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(hall_ticket) DO UPDATE SET name=excluded.name, branch=excluded.branch,
    batch=excluded.batch, semester=excluded.semester, record_json=excluded.record_json,
    updated_at=CURRENT_TIMESTAMP`);
  db.exec('BEGIN IMMEDIATE');
  try {
    for (const row of records) insert.run(row.hallTicket, row.name, row.branch, row.batch, row.semester, JSON.stringify(row));
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}
function getStudents() {
  return db.prepare('SELECT record_json FROM students ORDER BY hall_ticket').all().map((r) => JSON.parse(r.record_json));
}
function logEvent(event, detail = {}) {
  db.prepare('INSERT INTO audit_logs(event, detail_json) VALUES (?, ?)').run(event, JSON.stringify(detail));
}
function getRecentEvents(limit = 20) {
  return db.prepare('SELECT id, event, detail_json, created_at FROM audit_logs ORDER BY id DESC LIMIT ?').all(limit)
    .map((r) => ({ id: r.id, event: r.event, detail: JSON.parse(r.detail_json), createdAt: r.created_at }));
}
module.exports = { db, seedStudents, getStudents, logEvent, getRecentEvents };
