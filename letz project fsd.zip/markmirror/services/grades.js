// Grade scale + SGPA / CGPA maths. Everything credit weighted.

const GRADE_POINTS = { 'O': 10, 'A+': 9, 'A': 8, 'B+': 7, 'B': 6, 'C': 5, 'P': 4, 'F': 0 };

const PASS_TOTAL = 40;     // out of 100
const PASS_EXTERNAL = 24;  // 40% of the 60 external marks

function gradeFromMarks(internal, external) {
  const total = internal + external;
  // failing the external paper means F, no matter how good the internals were
  if (external < PASS_EXTERNAL || total < PASS_TOTAL) return 'F';
  if (total >= 90) return 'O';
  if (total >= 80) return 'A+';
  if (total >= 70) return 'A';
  if (total >= 60) return 'B+';
  if (total >= 55) return 'B';
  if (total >= 50) return 'C';
  return 'P';
}

const round2 = (n) => Math.round(n * 100) / 100;

// GPA = sum(credits * gradePoints) / sum(credits)
function calcSgpa(subjects) {
  let weighted = 0;
  let credits = 0;
  for (const s of subjects) {
    weighted += s.credits * GRADE_POINTS[s.grade];
    credits += s.credits;
  }
  return credits === 0 ? 0 : round2(weighted / credits);
}

// previousSemesters = [{ semester, sgpa, credits }]
function calcCgpa(previousSemesters, currentSgpa, currentCredits) {
  let weighted = currentSgpa * currentCredits;
  let credits = currentCredits;
  for (const sem of previousSemesters) {
    weighted += sem.sgpa * sem.credits;
    credits += sem.credits;
  }
  return round2(weighted / credits);
}

function classify(sgpa, backlogs) {
  if (backlogs > 0) return 'Not Promoted - Backlog(s) Pending';
  if (sgpa >= 8.5) return 'First Class with Distinction';
  if (sgpa >= 7) return 'First Class';
  if (sgpa >= 6) return 'Second Class';
  return 'Pass Class';
}

module.exports = { GRADE_POINTS, gradeFromMarks, calcSgpa, calcCgpa, classify, round2 };
