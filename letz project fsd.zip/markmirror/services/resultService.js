// All the result + analytics logic lives here so server.js stays small
// (and so we can test it without starting express).
const subjects = require('../data/subjects.json');
const seedStudents = require('../data/students.json');
const { seedStudents: persistStudents, getStudents } = require('./database');
if (getStudents().length === 0) persistStudents(seedStudents);
const rawStudents = getStudents();
const historicalBatches = require('../data/historical-batches.json');
const { gradeFromMarks, calcSgpa, calcCgpa, classify, round2 } = require('./grades');

const BRANCH_NAMES = {
  CSE: 'Computer Science & Engineering',
  AIDS: 'CSE (AI & Data Science)',
  IT: 'Information Technology',
  ECE: 'Electronics & Communication'
};

// fees per paper in rupees - change these if your university charges differently
const REEVAL_FEES = { recounting: 500, revaluation: 1000 };

const subjectMap = Object.fromEntries(subjects.map((s) => [s.code, s]));

// ---------- build full result for one student ----------
function buildResult(raw) {
  const rows = raw.subjects.map((m) => {
    const meta = subjectMap[m.code];
    const grade = gradeFromMarks(m.internal, m.external);
    return {
      code: m.code,
      name: meta.name,
      credits: meta.credits,
      internal: m.internal,
      external: m.external,
      total: m.internal + m.external,
      grade,
      passed: grade !== 'F'
    };
  });

  const sgpa = calcSgpa(rows);
  const totalCredits = rows.reduce((sum, r) => sum + r.credits, 0);
  const creditsEarned = rows.filter((r) => r.passed).reduce((sum, r) => sum + r.credits, 0);
  const totalMarks = rows.reduce((sum, r) => sum + r.total, 0);
  const backlogs = rows.filter((r) => !r.passed).length;

  return {
    hallTicket: raw.hallTicket,
    name: raw.name,
    branch: raw.branch,
    branchName: BRANCH_NAMES[raw.branch],
    batch: raw.batch,
    semester: raw.semester,
    subjects: rows,
    sgpa,
    cgpa: calcCgpa(raw.previousSemesters, sgpa, totalCredits),
    totalCredits,
    creditsEarned,
    totalMarks,
    maxMarks: rows.length * 100,
    percentage: round2(totalMarks / (rows.length * 100) * 100),
    backlogs,
    status: backlogs === 0 ? 'PASS' : 'FAIL',
    classification: classify(sgpa, backlogs),
    trend: [
      ...raw.previousSemesters.map((p) => ({ semester: p.semester, sgpa: p.sgpa })),
      { semester: raw.semester, sgpa }
    ]
  };
}

// compute everything once at startup - 120 records is nothing, but this keeps
// it snappy if someone swaps in a bigger dataset
const results = rawStudents.map(buildResult);
const byHallTicket = new Map(results.map((r) => [r.hallTicket, r]));

function rankedForBranch(branch) {
  return results
    .filter((r) => r.branch === branch)
    .sort((a, b) => b.sgpa - a.sgpa || b.totalMarks - a.totalMarks);
}

function getStudent(hallTicket) {
  const found = byHallTicket.get(String(hallTicket).trim().toUpperCase());
  if (!found) return null;
  const rank = rankedForBranch(found.branch).findIndex((r) => r.hallTicket === found.hallTicket) + 1;
  return { ...found, branchRank: rank, branchStrength: results.filter((r) => r.branch === found.branch).length };
}

function listBranches() {
  return Object.entries(BRANCH_NAMES).map(([code, name]) => ({ code, name }));
}

// ---------- analytics ----------
function pick(branch) {
  return branch && branch !== 'ALL' ? results.filter((r) => r.branch === branch) : results;
}

function histBatchFailRate(code) {
  const rates = historicalBatches.map((b) => b.subjectFailRates[code]);
  return rates.reduce((a, b) => a + b, 0) / rates.length;
}

function difficultyLabel(score) {
  if (score >= 25) return 'Hard';
  if (score >= 15) return 'Moderate';
  return 'Easy';
}

function getAnalytics(branch) {
  const group = pick(branch);
  const n = group.length;

  const subjectStats = subjects.map((sub) => {
    const rows = group.map((r) => r.subjects.find((x) => x.code === sub.code));
    const passCount = rows.filter((x) => x.passed).length;
    const avgMarks = rows.reduce((s, x) => s + x.total, 0) / n;
    const failRate = (1 - passCount / n) * 100;
    // difficulty index (0-100): this batch's failures + past batches' failures + how low the avg marks are
    const index = 0.5 * failRate + 0.3 * histBatchFailRate(sub.code) + 0.2 * (100 - avgMarks);
    return {
      code: sub.code,
      name: sub.name,
      credits: sub.credits,
      passCount,
      failCount: n - passCount,
      passRate: round2((passCount / n) * 100),
      failRate: round2(failRate),
      avgMarks: round2(avgMarks),
      difficultyIndex: round2(index),
      difficulty: difficultyLabel(index)
    };
  });

  // grade distribution across every paper
  const grades = ['O', 'A+', 'A', 'B+', 'B', 'C', 'P', 'F'];
  const gradeCounts = Object.fromEntries(grades.map((g) => [g, 0]));
  group.forEach((r) => r.subjects.forEach((s) => { gradeCounts[s.grade]++; }));

  // CGPA bins - upper edge belongs to the higher bin except 10 itself
  const bins = [
    { label: '9-10', min: 9, max: 10.01 },
    { label: '8-9', min: 8, max: 9 },
    { label: '7-8', min: 7, max: 8 },
    { label: '6-7', min: 6, max: 7 },
    { label: '5-6', min: 5, max: 6 },
    { label: 'Below 5', min: 0, max: 5 }
  ];
  const cgpaBins = bins.map((b) => ({
    label: b.label,
    count: group.filter((r) => r.cgpa >= b.min && r.cgpa < b.max).length
  }));

  const clearedAll = group.filter((r) => r.status === 'PASS').length;
  const avgSgpa = group.reduce((s, r) => s + r.sgpa, 0) / n;
  const avgCgpa = group.reduce((s, r) => s + r.cgpa, 0) / n;
  const distinction = group.filter((r) => r.sgpa >= 8.5 && r.status === 'PASS').length;
  const hardest = [...subjectStats].sort((a, b) => a.passRate - b.passRate)[0];
  const best = [...group].sort((a, b) => b.sgpa - a.sgpa)[0];

  const branchStats = Object.keys(BRANCH_NAMES).map((code) => {
    const g = results.filter((r) => r.branch === code);
    return {
      code,
      name: BRANCH_NAMES[code],
      students: g.length,
      passPercentage: round2((g.filter((r) => r.status === 'PASS').length / g.length) * 100),
      avgSgpa: round2(g.reduce((s, r) => s + r.sgpa, 0) / g.length)
    };
  });

  return {
    branch: branch && branch !== 'ALL' ? branch : 'ALL',
    summary: {
      students: n,
      passPercentage: round2((clearedAll / n) * 100),
      avgSgpa: round2(avgSgpa),
      avgCgpa: round2(avgCgpa),
      distinctionPercentage: round2((distinction / n) * 100),
      hardestSubject: hardest.name,
      hardestPassRate: hardest.passRate,
      topScorer: { name: best.name, hallTicket: best.hallTicket, sgpa: best.sgpa }
    },
    subjectStats,
    gradeDistribution: gradeCounts,
    cgpaBins,
    branchStats
  };
}

function getLeaderboard(branch) {
  const code = String(branch || 'CSE').toUpperCase();
  if (!BRANCH_NAMES[code]) return null;
  return rankedForBranch(code).slice(0, 10).map((r, i) => ({
    rank: i + 1,
    hallTicket: r.hallTicket,
    name: r.name,
    sgpa: r.sgpa,
    cgpa: r.cgpa,
    creditsEarned: r.creditsEarned,
    totalMarks: r.totalMarks
  }));
}

// ---------- batch comparison (2022 is live, older ones are stored) ----------
function compareBatches() {
  const live = getAnalytics('ALL');
  const current = {
    batch: 2022,
    students: live.summary.students,
    avgCgpa: live.summary.avgCgpa,
    passPercentage: live.summary.passPercentage,
    distinctionPercentage: live.summary.distinctionPercentage,
    subjectFailRates: Object.fromEntries(live.subjectStats.map((s) => [s.code, s.failRate]))
  };
  return {
    batches: [...historicalBatches, current],
    subjects: subjects.map((s) => ({ code: s.code, name: s.name }))
  };
}

// ---------- re-evaluation fee ----------
function estimateReeval(hallTicket, codes, type) {
  const student = byHallTicket.get(String(hallTicket).trim().toUpperCase());
  if (!student) return { error: 'Student not found', status: 404 };
  if (!REEVAL_FEES[type]) return { error: 'type must be "recounting" or "revaluation"', status: 400 };
  if (!Array.isArray(codes) || codes.length === 0) return { error: 'Pick at least one subject', status: 400 };

  const lines = [];
  for (const code of new Set(codes)) {
    const sub = student.subjects.find((s) => s.code === code);
    if (!sub) return { error: `Unknown subject code ${code}`, status: 400 };
    lines.push({ code, name: sub.name, fee: REEVAL_FEES[type] });
  }
  return {
    hallTicket: student.hallTicket,
    type,
    perPaperFee: REEVAL_FEES[type],
    lines,
    total: lines.reduce((s, l) => s + l.fee, 0)
  };
}

// Explainable academic intervention engine: every recommendation includes the data rule that triggered it.
function getInsights(branch = 'ALL') {
  const analytics = getAnalytics(branch);
  const group = pick(branch);
  const insights = [];
  for (const subject of analytics.subjectStats) {
    if (subject.failRate >= 20) insights.push({
      id: `subject-risk-${subject.code}`, priority: subject.failRate >= 35 ? 'high' : 'medium',
      title: `${subject.name} needs academic support`, category: 'subject-risk',
      evidence: `${subject.failRate}% current-batch failure rate (${subject.failCount} students)`,
      recommendation: 'Schedule a focused revision session, publish practice questions and review the most-missed topics.',
      metric: subject.failRate
    });
  }
  const atRisk = group.filter((student) => student.backlogs > 0 || student.sgpa < 6);
  if (atRisk.length) insights.push({
    id: 'cohort-at-risk', priority: atRisk.length / Math.max(group.length, 1) >= 0.2 ? 'high' : 'medium',
    title: 'Students may benefit from early intervention', category: 'student-support',
    evidence: `${atRisk.length} of ${group.length} students have a backlog or SGPA below 6.0`,
    recommendation: 'Offer faculty mentoring, backlog clinics and a follow-up assessment for this cohort.',
    metric: round2(atRisk.length / Math.max(group.length, 1) * 100)
  });
  const highPerformers = group.filter((student) => student.sgpa >= 9 && student.backlogs === 0);
  if (highPerformers.length) insights.push({
    id: 'high-performers', priority: 'low', title: 'Recognise high-performing students', category: 'positive-signal',
    evidence: `${highPerformers.length} students achieved SGPA of 9.0 or above with no backlogs`,
    recommendation: 'Consider peer-learning roles, merit recognition and advanced project opportunities.',
    metric: highPerformers.length
  });
  return { branch: branch || 'ALL', generatedAt: new Date().toISOString(), methodology: 'Transparent rules using current result data; this is decision support, not a prediction of individual outcomes.', insights };
}

module.exports = { getStudent, listBranches, getAnalytics, getLeaderboard, compareBatches, estimateReeval, getInsights, REEVAL_FEES };
