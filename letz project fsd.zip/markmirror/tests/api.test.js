const test = require('node:test');
const assert = require('node:assert/strict');
const app = require('../server');

test('API validates requests and exposes health and insights', async (t) => {
  const server = app.listen(0);
  await new Promise((resolve) => server.once('listening', resolve));
  t.after(() => server.close());
  const base = `http://127.0.0.1:${server.address().port}`;
  let response = await fetch(`${base}/api/health`);
  assert.equal(response.status, 200);
  response = await fetch(`${base}/api/student/!!`);
  assert.equal(response.status, 400);
  response = await fetch(`${base}/api/analytics?branch=NOPE`);
  assert.equal(response.status, 400);
  response = await fetch(`${base}/api/insights`);
  assert.equal(response.status, 200);
  assert.ok(Array.isArray((await response.json()).insights));
  response = await fetch(`${base}/api/reeval/estimate`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ hallTicket: '22CSE104', subjects: ['CS203'], type: 'wrong' }) });
  assert.equal(response.status, 400);
});
