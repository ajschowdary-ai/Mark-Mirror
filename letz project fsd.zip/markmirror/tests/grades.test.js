const test = require('node:test');
const assert = require('node:assert/strict');
const { gradeFromMarks, calcSgpa, calcCgpa, classify } = require('../services/grades');

test('grade boundaries respect external minimum and total marks', () => {
  assert.equal(gradeFromMarks(30, 60), 'O');
  assert.equal(gradeFromMarks(30, 50), 'A+');
  assert.equal(gradeFromMarks(20, 23), 'F');
  assert.equal(gradeFromMarks(15, 24), 'F');
  assert.equal(gradeFromMarks(16, 24), 'P');
});
test('SGPA is credit weighted and handles zero credits', () => {
  assert.equal(calcSgpa([{ credits: 4, grade: 'O' }, { credits: 2, grade: 'F' }]), 6.67);
  assert.equal(calcSgpa([]), 0);
});
test('CGPA combines semester credit weights', () => {
  assert.equal(calcCgpa([{ sgpa: 8, credits: 20 }], 10, 20), 9);
});
test('classification accounts for pending backlogs', () => {
  assert.equal(classify(9.5, 1), 'Not Promoted - Backlog(s) Pending');
  assert.equal(classify(8.5, 0), 'First Class with Distinction');
});
