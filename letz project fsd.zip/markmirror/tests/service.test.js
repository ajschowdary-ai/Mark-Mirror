const test = require('node:test');
const assert = require('node:assert/strict');
const svc = require('../services/resultService');

test('known hall ticket returns a calculated result and rank', () => {
  const result = svc.getStudent('22CSE104');
  assert.ok(result);
  assert.equal(result.hallTicket, '22CSE104');
  assert.ok(result.sgpa >= 0 && result.sgpa <= 10);
  assert.ok(result.branchRank >= 1);
});
test('unknown hall ticket returns null', () => assert.equal(svc.getStudent('NOTREAL123'), null));
test('analytics includes consistent cohort totals', () => {
  const data = svc.getAnalytics('ALL');
  assert.equal(data.summary.students, 120);
  assert.equal(data.subjectStats.length > 0, true);
});
test('insights are explainable and have evidence plus actions', () => {
  const data = svc.getInsights('ALL');
  assert.ok(Array.isArray(data.insights));
  for (const item of data.insights) {
    assert.ok(item.evidence);
    assert.ok(item.recommendation);
    assert.ok(['high', 'medium', 'low'].includes(item.priority));
  }
});
test('re-evaluation rejects unknown students and invalid types', () => {
  assert.equal(svc.estimateReeval('UNKNOWN', ['CS203'], 'revaluation').status, 404);
  assert.equal(svc.estimateReeval('22CSE104', ['CS203'], 'invalid').status, 400);
});
